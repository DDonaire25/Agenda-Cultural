import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { Calendar, Filter, MapPin, Phone, Instagram } from 'lucide-react-native';
import firestore from '@react-native-firebase/firestore';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

type Event = {
  id: string;
  title: string;
  description: string;
  date: Date;
  location: string;
  phone?: string;
  instagram?: string;
  imageUrl?: string;
  userName: string;
};

export default function EventsScreen() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const subscriber = firestore()
      .collection('events')
      .orderBy('date', 'asc')
      .onSnapshot(querySnapshot => {
        const eventsList: Event[] = [];
        querySnapshot.forEach(doc => {
          const data = doc.data();
          eventsList.push({
            id: doc.id,
            ...data,
            date: data.date.toDate(),
          } as Event);
        });
        setEvents(eventsList);
        setLoading(false);
      });

    return () => subscriber();
  }, []);

  const renderEvent = ({ item }: { item: Event }) => (
    <View style={styles.eventCard}>
      {item.imageUrl && (
        <Image source={{ uri: item.imageUrl }} style={styles.eventImage} />
      )}
      
      <View style={styles.eventContent}>
        <Text style={styles.eventTitle}>{item.title}</Text>
        <Text style={styles.eventDate}>
          {format(item.date, "EEEE d 'de' MMMM 'a las' HH:mm", { locale: es })}
        </Text>
        
        <View style={styles.eventLocation}>
          <MapPin size={16} color="#666" />
          <Text style={styles.eventLocationText}>{item.location}</Text>
        </View>

        <Text style={styles.eventDescription} numberOfLines={3}>
          {item.description}
        </Text>

        <View style={styles.eventFooter}>
          <Text style={styles.eventAuthor}>Por {item.userName}</Text>
          
          <View style={styles.eventContacts}>
            {item.phone && (
              <TouchableOpacity style={styles.contactButton}>
                <Phone size={20} color="#6A1B9A" />
              </TouchableOpacity>
            )}
            {item.instagram && (
              <TouchableOpacity style={styles.contactButton}>
                <Instagram size={20} color="#6A1B9A" />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Eventos Culturales</Text>
        <TouchableOpacity style={styles.filterButton}>
          <Filter size={20} color="#6A1B9A" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={events}
        renderItem={renderEvent}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Calendar size={48} color="#6A1B9A" />
            <Text style={styles.emptyStateText}>
              {loading ? 'Cargando eventos...' : 'No hay eventos disponibles'}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontFamily: 'Roboto-Bold',
    fontSize: 24,
    color: '#6A1B9A',
  },
  filterButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
  },
  list: {
    gap: 20,
  },
  eventCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  eventImage: {
    width: '100%',
    height: 200,
  },
  eventContent: {
    padding: 16,
    gap: 8,
  },
  eventTitle: {
    fontFamily: 'Roboto-Bold',
    fontSize: 18,
    color: '#333',
  },
  eventDate: {
    fontFamily: 'Roboto-Medium',
    fontSize: 14,
    color: '#6A1B9A',
  },
  eventLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  eventLocationText: {
    fontFamily: 'Roboto-Regular',
    fontSize: 14,
    color: '#666',
  },
  eventDescription: {
    fontFamily: 'Roboto-Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  eventAuthor: {
    fontFamily: 'Roboto-Medium',
    fontSize: 14,
    color: '#666',
  },
  eventContacts: {
    flexDirection: 'row',
    gap: 12,
  },
  contactButton: {
    padding: 8,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100,
  },
  emptyStateText: {
    fontFamily: 'Roboto-Medium',
    fontSize: 16,
    color: '#666',
    marginTop: 16,
  },
});